let net;

async function loadModel() {
  net = await mobilenet.load();
  console.log("Model Loaded!");
}

loadModel();

document.getElementById('imageUpload').addEventListener('change', function (e) {
  const reader = new FileReader();
  reader.onload = function () {
    document.getElementById('uploadedImage').src = reader.result;
  }
  reader.readAsDataURL(e.target.files[0]);
});

async function classifyImage() {
  const image = document.getElementById('uploadedImage');
  const result = await net.classify(image);
  document.getElementById('result').innerText = "Prediction: " + result[0].className;
}
